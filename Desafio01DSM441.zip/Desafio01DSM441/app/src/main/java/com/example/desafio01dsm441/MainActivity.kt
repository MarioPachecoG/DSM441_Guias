package com.example.desafio01dsm441

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var editTextMonto: EditText
    private lateinit var editTextPersona: EditText
    private lateinit var radio10: RadioButton
    private lateinit var radio15: RadioButton
    private lateinit var radio20: RadioButton
    private lateinit var radioOtro: RadioButton
    private lateinit var btnCalcular: Button
    private lateinit var btnLimpiar: Button
    private lateinit var radioGroup: RadioGroup
    private lateinit var switchIva: Switch
    private lateinit var txtResultado: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editTextMonto = findViewById(R.id.etMontoTotal)
        editTextPersona = findViewById(R.id.etNumeroPersonas)
        radio10 = findViewById(R.id.radio10)
        radio15 = findViewById(R.id.radio15)
        radio20 = findViewById(R.id.radio20)
        radioOtro = findViewById(R.id.radioOtro)
        radioGroup = findViewById(R.id.radioGroupPropina)
        btnCalcular = findViewById(R.id.btnCalcular)
        btnLimpiar = findViewById(R.id.btnLimpiar)
        switchIva = findViewById(R.id.switchIVA)
        txtResultado = findViewById(R.id.textViewResultado)

        btnCalcular.setOnClickListener {
            calcularPropina()
        }

        btnLimpiar.setOnClickListener {
            limpiarCampos()
        }
    }

    private fun calcularPropina() {
        val montoStr = editTextMonto.text.toString()
        val personasStr = editTextPersona.text.toString()

        // Validación básica de campos
        if (montoStr.isBlank() || personasStr.isBlank()) {
            Toast.makeText(this, "Completa todos los campos", Toast.LENGTH_SHORT).show()
            return
        }

        val monto = montoStr.toDoubleOrNull()
        val personas = personasStr.toIntOrNull()

        // Validación de datos numéricos, valores negativos y cero
        if (monto == null || monto <= 0 || personas == null || personas <= 0) {
            Toast.makeText(this, "Datos inválidos o negativos no permitidos", Toast.LENGTH_SHORT).show()
            return
        }

        val porcentaje = when {
            radio10.isChecked -> 0.10
            radio15.isChecked -> 0.15
            radio20.isChecked -> 0.20
            radioOtro.isChecked -> {
                pedirOtroPorcentaje()
                return
            }
            else -> {
                Toast.makeText(this, "Selecciona un porcentaje", Toast.LENGTH_SHORT).show()
                return
            }
        }

        // Calcular IVA si el Switch está activado
        val iva = if (switchIva.isChecked) {
            monto * 0.16 // 16% de IVA
        } else {
            0.0
        }

        // Monto con IVA
        val montoConIva = monto + iva

        // Calcular la propina sobre el monto con IVA
        val propina = montoConIva * porcentaje
        val total = montoConIva + propina
        val porPersona = total / personas

        // Mostrar los resultados en el TextView
        val mensaje = """
            Total con o sin IVA: $%.2f
            Propina: $%.2f
            Total con propina: $%.2f
            Cantidad a pagar por persona: $%.2f
        """.trimIndent().format(montoConIva, propina, total, porPersona)

        txtResultado.text = mensaje
    }

    private fun pedirOtroPorcentaje() {
        val editText = EditText(this)
        editText.hint = "Ej: 5 para 5%"

        val dialog = android.app.AlertDialog.Builder(this)
            .setTitle("Ingrese otro porcentaje")
            .setView(editText)
            .setPositiveButton("Aceptar") { _, _ ->
                val input = editText.text.toString().toDoubleOrNull()
                if (input == null || input <= 0) {
                    Toast.makeText(this, "Porcentaje inválido", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                val monto = editTextMonto.text.toString().toDoubleOrNull() ?: return@setPositiveButton
                val personas = editTextPersona.text.toString().toIntOrNull() ?: return@setPositiveButton

                val propina = monto * (input / 100)
                val total = monto + propina
                val porPersona = total / personas

                val mensaje = """
                    Total con propina: $%.2f
                    A pagar por persona: $%.2f
                """.trimIndent().format(total, porPersona)

                txtResultado.text = mensaje
            }
            .setNegativeButton("Cancelar", null)
            .create()

        dialog.show()
    }

    private fun limpiarCampos() {
        editTextMonto.text.clear()
        editTextPersona.text.clear()
        radioGroup.clearCheck()
        switchIva.isChecked = false
        txtResultado.text = ""
    }
}